﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrimerParcial
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Inscrito myInscripcion = new Inscrito();
            Console.WriteLine(myInscripcion.Mostrar());
        }
    }
}
