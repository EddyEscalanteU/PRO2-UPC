﻿using System;

namespace ClaseEntero
{
    public class Program
    {
        public static void MostrarDigImpares(int N)
        {
            int NroAux = N;
            while (NroAux != 0)
            {
                int dig = NroAux % 10;
                if (dig % 2 != 0)
                {
                    Console.WriteLine("Dig: " + dig);
                }
                NroAux = NroAux / 10;
            }
        }

        public static void MostrarDigImparesRecursivo(int N)
        {
            if (N != 0)
            {
                int dig = N % 10;
                if (dig % 2 != 0)
                {
                    Console.WriteLine("Dig: " + dig);
                }
                MostrarDigImparesRecursivo(N / 10);
            }
        }

        public static void Main(string[] args)
        {
            int valorN = 123456;
            Console.WriteLine("MostrarDigImpares:");
            MostrarDigImpares(valorN);

            int valorN2 = 123456;
            Console.WriteLine("MostrarDigImparesRecursivo:");
            MostrarDigImparesRecursivo(valorN2);
        }
    }
}